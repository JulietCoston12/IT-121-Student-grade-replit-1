
let namesArray = ["Jim|25, Sue|32, Mary|34, Ann|22, Ted|28, Frank|15, Lisa|19, Mike|30, Ahn|26, Vishaya|27"];
}
let  stuentsArray = ['Jim',  'Sue', 'Mary', 'Ann', 'Ted', 'Frank', 'Lisa', 'Mike', 'Aha', 'Vishaya'];
for (let i =0; i<names.lemgth; i++){
  sumList +namesArray[i];
}
console.log(sumList.length);
 StudentsGrade.pop(names);
const names = "Jim,  Sue, Mary, Ann, Ted".split(names);

    names [0]  = "Ted", // replace with jim.
    names.push("Frank");


const person = StudentsGradeArrayname.split(","); // split the initial string into and array and return my arrays

   // names[0] = "jim|25"
   // create a new array to hold all of the student names students[0]
   // create a new array to hold all of the score
   console.log(StudentsName);
   console.log(...ArrayList, StudentsGrade);

 
  for(let i = 0; i < scored.length; i++) { // correct the loop to iterate over grade.lenght
     parseInt(grades[i].split('|')[i]); // Use parseInt() to convert the string to integer
   }

  function getAverage(a, b ) {
const student=  [score1, score2, score3];
const name = ["Jim"/25, "Sue"/32, "Mary"/34, "Ann"/22, "Ted"/28, "Frank"/15, "Lisa"/19, "Mike"/30, "Aha"/26, "Vishaya"/27];
grades.split(" ,");
document.getElementById("demo").innerHTML = grades.toString('...'); // use tostring() to convert to string
   console.log(grades.toString('...')); // use toString without parameters to create a string from thr array elements
   console.log(student.indexOf(15)); // Use indexOf() to find the position of the element in the array

   for (let i = 0; i < student.lenght; i++) {
  console.log(student[i]);

  }
}


const myArray = ["Jim|25, Sue|32, Mary|34, Ann|22, Ted|28, Frank|15, Lisa|19, Mike|30, Ahn|26, Vishaya|27"];

let  stuents = ['Jim',  'Sue', 'Mary', 'Ann', 'Ted', 'Frank', 'Lisa', 'Mike', 'Aha', 'Vishaya'];
for (let i =0; i<myArray.lemgth; i++){
  sumList += myArray[i];
}
console.log(sumList.length);
 StudentsGrade.pop(myArray);
let StudentsGrade  = ["Jim|25, Sue|32, Mary|34, Ann|22, Ted|28, Frank|15, Lisa|19, Mike|30, Ahn|26, Vishaya|27"];

 const sumList = StudentsGradeStudentsName.split(","); // split the initial string into and array and return my arrays

   // names[0] = "jim|25"
   // create a new array to hold all of the student names students[0]
   // create a new array to hold all of the score
   console.log(StudentsName);
   console.log(...sumList, StudentsGrade);

 let Studentsscore = [25, 32, 34, 22, 28, 15, 19, 30, 26, 27];
   console.log(scores)
  // document.getElementId("Scores").value; // correctly reference to score indexOf(student.name);
   console.log(', '); // use console.join() to create a string from the array elements

  for(let i = 0; i < scored.length; i++) { // correct the loop to iterate over grade.lenght
     parseInt(grades[i].split('|')[i]); // Use parseInt() to convert the string to integer
   }

  function getAverage(a, b ) {
const student=  [score1, score2, score3];
const name = ["Jim"/25, "Sue"/32, "Mary"/34, "Ann"/22, "Ted"/28, "Frank"/15, "Lisa"/19, "Mike"/30, "Aha"/26, "Vishaya"/27];
grades.split(" ,");
document.getElementById("demo").innerHTML = grades.toString('...'); // use tostring() to convert to string
   console.log(grades.toString('...')); // use toString without parameters to create a string from thr array elements
   console.log(student.indexOf(15)); // Use indexOf() to find the position of the element in the array

   for (let i = 0; i < student.lenght; i++) {
  console.log(student[i]);

  }
}


const myArray = ["Jim|25, Sue|32, Mary|34, Ann|22, Ted|28, Frank|15, Lisa|19, Mike|30, Ahn|26, Vishaya|27"];

let  stuents = ['Jim',  'Sue', 'Mary', 'Ann', 'Ted', 'Frank', 'Lisa', 'Mike', 'Aha', 'Vishaya'];
for (let i =0; i<myArray.lemgth; i++){
  sumList += myArray[i];
}
console.log(sumList.length);
 StudentsGrade.pop(myArray);
let StudentsGrade  = ["Jim|25, Sue|32, Mary|34, Ann|22, Ted|28, Frank|15, Lisa|19, Mike|30, Ahn|26, Vishaya|27"];

 const sumList = StudentsGradeStudentsName.split(","); // split the initial string into and array and return my arrays

   // names[0] = "jim|25"
   // create a new array to hold all of the student names students[0]
   // create a new array to hold all of the score
   console.log(StudentsName);
   console.log(...sumList, StudentsGrade);

 let Studentsscore = [25, 32, 34, 22, 28, 15, 19, 30, 26, 27];
   console.log(scores)
  // document.getElementId("Scores").value; // correctly reference to score indexOf(student.name);
   console.log(', '); // use console.join() to create a string from the array elements

  for(let i = 0; i < scored.length; i++) { // correct the loop to iterate over grade.lenght
     parseInt(grades[i].split('|')[i]); // Use parseInt() to convert the string to integer
   }

  function getAverage(a, b ) {
const student=  [score1, score2, score3];
const name = ["Jim"/25, "Sue"/32, "Mary"/34, "Ann"/22, "Ted"/28, "Frank"/15, "Lisa"/19, "Mike"/30, "Aha"/26, "Vishaya"/27];
grades.split(" ,");
document.getElementById("demo").innerHTML = grades.toString('...'); // use tostring() to convert to string
   console.log(grades.toString('...')); // use toString without parameters to create a string from thr array elements
   console.log(student.indexOf(15)); // Use indexOf() to find the position of the element in the array

   for (let i = 0; i < student.lenght; i++) {
  console.log(student[i]);

  }
}


const myArray = ["Jim|25, Sue|32, Mary|34, Ann|22, Ted|28, Frank|15, Lisa|19, Mike|30, Ahn|26, Vishaya|27"];

let  stuents = ['Jim',  'Sue', 'Mary', 'Ann', 'Ted', 'Frank', 'Lisa', 'Mike', 'Aha', 'Vishaya'];
for (let i =0; i<myArray.lemgth; i++){
  sumList += myArray[i];
}
console.log(sumList.length);
 StudentsGrade.pop(myArray);
let StudentsGrade  = ["Jim|25, Sue|32, Mary|34, Ann|22, Ted|28, Frank|15, Lisa|19, Mike|30, Ahn|26, Vishaya|27"];

 

  for(let i = 0; i < scored.length; i++) { // correct the loop to iterate over grade.lenght
     parseInt(grades[i].split('|')[i]); // Use parseInt() to convert the string to integer
   }

  function getAverage(a, b ) {
const student=  [score1, score2, score3];
const name = ["Jim"/25, "Sue"/32, "Mary"/34, "Ann"/22, "Ted"/28, "Frank"/15, "Lisa"/19, "Mike"/30, "Aha"/26, "Vishaya"/27];
grades.split(" ,");
document.getElementById("demo").innerHTML = grades.toString('...'); // use tostring() to convert to string
   console.log(grades.toString('...')); // use toString without parameters to create a string from thr array elements
   console.log(student.indexOf(15)); // Use indexOf() to find the position of the element in the array

   for (let i = 0; i < student.lenght; i++) {
  console.log(student[i]);

  }
}


const myArray = ["Jim|25, Sue|32, Mary|34, Ann|22, Ted|28, Frank|15, Lisa|19, Mike|30, Ahn|26, Vishaya|27"];

let  stuents = ['Jim',  'Sue', 'Mary', 'Ann', 'Ted', 'Frank', 'Lisa', 'Mike', 'Aha', 'Vishaya'];
for (let i =0; i<myArray.lemgth; i++){
  sumList += myArray[i];
}
console.log(sumList.length);
 StudentsGrade.pop(myArray);
let StudentsGrade  = ["Jim|25, Sue|32, Mary|34, Ann|22, Ted|28, Frank|15, Lisa|19, Mike|30, Ahn|26, Vishaya|27"];

 const sumList = StudentsGradeStudentsName.split(","); // split the initial string into and array and return my arrays

   // names[0] = "jim|25"
   // create a new array to hold all of the student names students[0]
   // create a new array to hold all of the score
   console.log(StudentsName);
   console.log(...sumList, StudentsGrade);


  for(let i = 0; i < scored.length; i++) { // correct the loop to iterate over grade.lenght
     parseInt(grades[i].split('|')[i]); // Use parseInt() to convert the string to integer
   }

  function getAverage(a, b ) {
const student=  [score1, score2, score3];
const name = ["Jim"/25, "Sue"/32, "Mary"/34, "Ann"/22, "Ted"/28, "Frank"/15, "Lisa"/19, "Mike"/30, "Aha"/26, "Vishaya"/27];
grades.split(" ,");
document.getElementById("demo").innerHTML = grades.toString('...'); // use tostring() to convert to string
   console.log(grades.toString('...')); // use toString without parameters to create a string from thr array elements
   console.log(student.indexOf(15)); // Use indexOf() to find the position of the element in the array

   for (let i = 0; i < student.lenght; i++) {
  console.log(student[i]);

  }
}


